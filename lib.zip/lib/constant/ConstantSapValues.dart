class ConstantValues {
  static String? tenetID = '';
  //static String sapUserID = '';
  static String sapUserType = '';
  static String slpcode = '';
  static String appversion = '';
  static String? firstName = '';
  static String? lastName = '';
  static String? profilepic = '';
  static String? mailId = '';
  static String? phoneNum = '';
  static String? branch = '';
  static String? deviceId = '';
  static String? managerPhonenum='';
  static String? userNamePM='';
  static String token='';
  static String UserId='';
   static int? storeid;
  //  static String storeCode='';

   //
   static String ipaddress='';
   static String ipname='';
   static String? latitude='';
   static String? langtitude='';
   static String? headerSetup='';
static String? EncryptedSetup='';
static String? Storecode='';
static String? Usercode='';
static String? Password='';
//
static String? Country='INDIA';
static int? slidevalue=10;

  static String? sellerkitCallerappFCm;

}
