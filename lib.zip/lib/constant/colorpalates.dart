 import 'package:flutter/material.dart';

class Palettes {
  static const Color primary1 = Color.fromRGBO(4, 88,150, 100);
  static const Color primary2 = Color.fromRGBO(243, 153,43, 100);
  static const Color primary3 = Color.fromRGBO(207, 43,33 , 100);
  static const Color primary4 = Color.fromRGBO(11, 142,76, 100);
  static const Color primary5 = Color.fromRGBO(189, 150,179, 100);

  //8D355C  AB587D  D087A8  FCB9D7
  }