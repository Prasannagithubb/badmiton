import 'package:flutter/material.dart';

class DashCoachProvider extends ChangeNotifier {

  final coachformKey = GlobalKey<FormState>();

    List<TextEditingController> coachcontroller =
      List.generate(10, (i) => TextEditingController());


}
