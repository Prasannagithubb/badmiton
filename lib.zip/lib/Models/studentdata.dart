class StudentData {
  final String title;
  final int count;
  final int newStudents;
  final String period;

  StudentData({
    required this.title,
    required this.count,
    required this.newStudents,
    required this.period,
  });
}
