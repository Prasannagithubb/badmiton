
import 'package:flutter/material.dart';

class TakeQuiry extends StatefulWidget {
  const TakeQuiry({super.key});

  @override
  State<TakeQuiry> createState() => _TakeQuiryState();
}

class _TakeQuiryState extends State<TakeQuiry> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      
    );
  }
}