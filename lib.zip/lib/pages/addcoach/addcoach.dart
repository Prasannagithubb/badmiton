import 'dart:io';
import 'package:badmiton_app/constant/Screen.dart';
import 'package:badmiton_app/controller/dashaddcoach.dart/dash_coach_provider.dart';
import 'package:badmiton_app/controller/dashbatchconroller/batch_list_provider.dart';
import 'package:badmiton_app/controller/dashstudentcontroller.dart/add_student_provider.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class AddCouch extends StatefulWidget {
  const AddCouch({super.key});

  @override
  _AddCouchState createState() => _AddCouchState();
}

class _AddCouchState extends State<AddCouch> {
  DateTime? selectedDateOfBirth;
  XFile? _image; // This will hold the image file
  final ImagePicker _picker = ImagePicker(); // Create an ImagePicker instance

  // Function to handle image picking
  Future<void> _pickImagecoach() async {
    try {
      final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        setState(() {
          _image = pickedFile;
        });
      }
    } catch (e) {
      print('Image picker error: $e');
    }
  }

  bool _isLoading = false;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {});
  }

  void updateTextController() {
    batchController.text = context.read<BatchListProvider>().selectedBatch ??
        ""; // Set controller text to the selected batch or empty if null
  }

  DateTime? dateOfBirth;

  void _selectDateOfBirth(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDateOfBirth ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != selectedDateOfBirth) {
      setState(() {
        selectedDateOfBirth = picked;
      });
    }
  }

  TextEditingController batchController = TextEditingController();
  List<String> selectedWeekdays = []; // List to store selected weekdays
  List<String> selectedWeekends = [];
  bool isChecked = false;
  List<bool> checkboxValues = List.generate(8, (index) => false);

  @override
  Widget build(BuildContext context) {
    AddStudentProvider addStudentProvider =
        Provider.of<AddStudentProvider>(context, listen: false);
    final studentcurrentTime = TimeOfDay.now();
    ThemeData theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        elevation: 6.0,
        shadowColor: Colors.black,
        centerTitle: true,
        leading: const Icon(
          Icons.menu,
          color: Colors.white,
        ),
        title: const Text(
          'Add student',
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          Padding(
            padding: EdgeInsets.all(Screens.bodyheight(context) * 0.02),
            child: const Icon(
              Icons.search,
              color: Colors.white,
            ),
          ),
          Padding(
            padding: EdgeInsets.all(Screens.bodyheight(context) * 0.02),
            child: const Icon(
              Icons.notifications,
              color: Colors.white,
            ),
          ),
        ],
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              GestureDetector(
                onTap: _pickImagecoach, // Use the _pickImage function here
                child: CircleAvatar(
                  radius: 60,
                  backgroundImage: _image != null
                      ? FileImage(File(_image!.path)) as ImageProvider
                      : const AssetImage(
                          'lib/assets/peopleplaceholder.png'), // Placeholder image
                  backgroundColor: Colors.grey[200], // Default background color
                ),
              ),
              const SizedBox(height: 20),
              Form(
          key: context.read<DashCoachProvider>().coachformKey,
          child: ListView(
            children: [
              TextFormField(
                controller: context
                          .watch<DashCoachProvider>()
                          .coachcontroller[0],
                decoration: const InputDecoration(labelText: 'Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a name';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: context
                          .watch<DashCoachProvider>()
                          .coachcontroller[1],
                decoration: const InputDecoration(labelText: 'Mobile'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter a mobile number';
                  }
                  return null;
                },
                keyboardType: TextInputType.phone,
              ),
              ElevatedButton(
                onPressed: () {
                  // Add logic to upload ID Card image
                },
                child: const Text('Upload ID Card'),
              ),
              TextFormField(
                controller: context
                          .watch<DashCoachProvider>()
                          .coachcontroller[2],
                decoration: const InputDecoration(labelText: 'Salary'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the salary';
                  }
                  return null;
                },
                keyboardType: TextInputType.number,
              ),
              TextFormField(
                controller: context
                          .watch<DashCoachProvider>()
                          .coachcontroller[3],
                
                decoration: const InputDecoration(labelText: 'Bank Details'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter bank details';
                  }
                  return null;
                },
                keyboardType: TextInputType.number,
              ),
              ElevatedButton(
                onPressed: () {
                  // Add logic to upload Bank Passbook image
                },
                child: const Text('Upload Bank Passbook'),
              ),
              TextFormField(
                 controller: context
                          .watch<DashCoachProvider>()
                          .coachcontroller[4],
                
                decoration: const InputDecoration(labelText: 'Date of Joining'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the date of joining';
                  }
                  return null;
                },
                keyboardType: TextInputType.datetime,
              ),
              TextFormField(
                controller: context
                          .watch<DashCoachProvider>()
                          .coachcontroller[5],
                
                decoration: const InputDecoration(labelText: 'Date of Resignation'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the date of resignation';
                  }
                  return null;
                },
                keyboardType: TextInputType.datetime,
              ),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    // Form is valid, submit the data
                    _submitForm();
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
            ]
      ),
              // if (!_isLoading) // Only show the button if not loading
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    final studentProvider = context.read<AddStudentProvider>();
                    if (studentProvider.studentcondition) {
                      // If studentcondition is true, perform edit operation
                      studentProvider.updatedstudent();
                    } else {
                      // If studentcondition is false or studentProvider is null, perform add operation
                      studentProvider.addstudentlist(context);
                    }
                  });
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  'Save',
                  style: TextStyle(color: Colors.blue),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  SizedBox Formdategap(BuildContext context) =>
      SizedBox(width: Screens.width(context) * 0.001);
}
